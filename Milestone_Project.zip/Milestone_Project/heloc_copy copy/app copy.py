# from flask import Flask, render_template, request, jsonify
# import joblib
# import numpy as np
# from tensorflow.keras.models import load_model

# # Initialize Flask app
# app = Flask(__name__)

# # Load the model and scaler
# model = load_model('model.h5')
# scaler = joblib.load('scaler.pkl')

# # Define the home route
# @app.route('/')
# def home():
#     return render_template('index.html')

# # @app.route('/predict', methods=['POST'])
# # def predict():
# #     try:
# #         print("Received form data:", request.form)
# #         # Gather additional questions to determine ExternalRiskEstimate
# #         age = request.form.get('age', type=int)
# #         employed = request.form.get('employed') == 'yes'
# #         annual_income = request.form.get('annual_income', type=float)
# #         estimated_value_assets = request.form.get('estimated_value_assets', type=float)
# #         months_open_credit_account = request.form.get('months_open_credit_account', type=int)
# #         number_of_credit_accounts = request.form.get('number_of_credit_accounts', type=int)
# #         overdue_60_days = request.form.get('overdue_60_days') == 'yes'
        
# #         # Debugging logs
# #         print("Received input data:")
# #         print(f"Age: {age}, Employed: {employed}, Annual Income: {annual_income}, Estimated Value of Assets: {estimated_value_assets}, Months Open Credit Account: {months_open_credit_account}, Number of Credit Accounts: {number_of_credit_accounts}, Overdue 60 Days: {overdue_60_days}")


# #         # Check for None values and handle them appropriately
# #         if None in (age, annual_income, estimated_value_assets, months_open_credit_account, number_of_credit_accounts):
# #             return jsonify({'error': 'Missing input data.'}), 400

# #         # Simple risk estimation logic based on the input (customize as needed)
# #         ExternalRiskEstimate = (
# #             (age / 100) * 20 +  # Example: age affects risk (0-20)
# #             (1 if employed else 0) * 20 +  # Employment status (0-20)
# #             (annual_income / 100000) * 30 +  # Income influences risk (0-30)
# #             (estimated_value_assets / 100000) * 20 +  # Asset value influences risk (0-20)
# #             (months_open_credit_account / 100) * 5 +  # Longer credit history is better (0-5)
# #             (number_of_credit_accounts / 10) * 5 +  # More accounts can mean higher risk (0-5)
# #             (-10 if overdue_60_days else 0)  # Negative impact if overdue (down to -10)
# #         )

# #         # Ensure ExternalRiskEstimate is within [0, 100]
# #         ExternalRiskEstimate = max(0, min(100, ExternalRiskEstimate))

# #         # Extract form data corresponding to the original 23 features
# #         input_data = [
# #             ExternalRiskEstimate,
# #             float(request.form.get('MSinceOldestTradeOpen', 50)),
# #             float(request.form.get('MSinceMostRecentTradeOpen', 50)),
# #             float(request.form.get('AverageMInFile', 24)),
# #             float(request.form.get('NumSatisfactoryTrades', 10)),
# #             float(request.form.get('NumTrades60Ever2DerogPubRec', 0)),
# #             float(request.form.get('NumTrades90Ever2DerogPubRec', 0)),
# #             float(request.form.get('PercentTradesNeverDelq', 100)),
# #             float(request.form.get('MSinceMostRecentDelq', 12)),
# #             float(request.form.get('MaxDelq2PublicRecLast12M', 0)),
# #             float(request.form.get('MaxDelqEver', 0)),
# #             float(request.form.get('NumTotalTrades', 5)),
# #             float(request.form.get('NumTradesOpeninLast12M', 0)),
# #             float(request.form.get('PercentInstallTrades', 1)),
# #             float(request.form.get('MSinceMostRecentInqexcl7days', 12)),
# #             float(request.form.get('NumInqLast6M', 0)),
# #             float(request.form.get('NumInqLast6Mexcl7days', 0)),
# #             float(request.form.get('NetFractionRevolvingBurden', 21)),
# #             float(request.form.get('NetFractionInstallBurden', 12)),
# #             float(request.form.get('NumRevolvingTradesWBalance', 1)),
# #             float(request.form.get('NumInstallTradesWBalance', 0)),
# #             float(request.form.get('NumBank2NatlTradesWHighUtilization', 3)),
# #             float(request.form.get('PercentTradesWBalance', 3))
# #         ]

# #         # Convert input data to numpy array and reshape for prediction
# #         input_data = np.array(input_data).reshape(1, -1)

# #         # Scale the data before feeding into the model
# #         scaled_data = scaler.transform(input_data)

# #         # Make a prediction
# #         prediction = model.predict(scaled_data)
# #         prediction = (prediction > 0.5).astype(int)

# #         return jsonify({'prediction': 'Bad' if prediction[0][0] == 1 else 'Good'})

# #     except Exception as e:
# #         return jsonify({'error': str(e)})

# @app.route('/predict', methods=['POST'])
# def predict():
#     try:
#         # Gather input values and log them
#         age = request.form.get('age', type=int)
#         employed = request.form.get('employed') == 'yes'
#         annual_income = request.form.get('annual_income', type=float)
#         estimated_value_assets = request.form.get('estimated_value_assets', type=float)
#         months_open_credit_account = request.form.get('months_open_credit_account', type=int)
#         number_of_credit_accounts = request.form.get('number_of_credit_accounts', type=int)
#         overdue_60_days = request.form.get('overdue_60_days') == 'yes'

#         # Additional fields
#         MSinceOldestTradeOpen = request.form.get('MSinceOldestTradeOpen', type=float)
#         MSinceMostRecentTradeOpen = request.form.get('MSinceMostRecentTradeOpen', type=float)
#         AverageMInFile = request.form.get('AverageMInFile', type=float)
#         NumSatisfactoryTrades = request.form.get('NumSatisfactoryTrades', type=float)
#         NumTrades60Ever2DerogPubRec = request.form.get('NumTrades60Ever2DerogPubRec', type=float)
#         NumTrades90Ever2DerogPubRec = request.form.get('NumTrades90Ever2DerogPubRec', type=float)
#         PercentTradesNeverDelq = request.form.get('PercentTradesNeverDelq', type=float)
#         MSinceMostRecentDelq = request.form.get('MSinceMostRecentDelq', type=float)
#         MaxDelq2PublicRecLast12M = request.form.get('MaxDelq2PublicRecLast12M', type=float)
#         MaxDelqEver = request.form.get('MaxDelqEver', type=float)
#         NumTotalTrades = request.form.get('NumTotalTrades', type=float)
#         NumTradesOpeninLast12M = request.form.get('NumTradesOpeninLast12M', type=float)
#         PercentInstallTrades = request.form.get('PercentInstallTrades', type=float)
#         MSinceMostRecentInqexcl7days = request.form.get('MSinceMostRecentInqexcl7days', type=float)
#         NumInqLast6M = request.form.get('NumInqLast6M', type=float)
#         NumInqLast6Mexcl7days = request.form.get('NumInqLast6Mexcl7days', type=float)
#         NetFractionRevolvingBurden = request.form.get('NetFractionRevolvingBurden', type=float)
#         NetFractionInstallBurden = request.form.get('NetFractionInstallBurden', type=float)
#         NumRevolvingTradesWBalance = request.form.get('NumRevolvingTradesWBalance', type=float)
#         NumInstallTradesWBalance = request.form.get('NumInstallTradesWBalance', type=float)
#         NumBank2NatlTradesWHighUtilization = request.form.get('NumBank2NatlTradesWHighUtilization', type=float)
#         PercentTradesWBalance = request.form.get('PercentTradesWBalance', type=float)

#         # Log the received input data
#         print("Received input data:")
#         print(f"Age: {age}, Employed: {employed}, Annual Income: {annual_income}, Estimated Value of Assets: {estimated_value_assets}")
#         print(f"Months Open Credit Account: {months_open_credit_account}, Number of Credit Accounts: {number_of_credit_accounts}, Overdue 60 Days: {overdue_60_days}")
#         print(f"MSinceOldestTradeOpen: {MSinceOldestTradeOpen}, MSinceMostRecentTradeOpen: {MSinceMostRecentTradeOpen}")
#         # Continue logging all other variables...

#         # Check for None values
#         if any(field is None for field in [age, annual_income, estimated_value_assets, months_open_credit_account, number_of_credit_accounts]):
#             return jsonify({'error': 'Missing input data.'}), 400

#         # Extract additional features into a list
#         input_data = [
#             MSinceOldestTradeOpen, MSinceMostRecentTradeOpen, AverageMInFile, NumSatisfactoryTrades,
#             NumTrades60Ever2DerogPubRec, NumTrades90Ever2DerogPubRec, PercentTradesNeverDelq,
#             MSinceMostRecentDelq, MaxDelq2PublicRecLast12M, MaxDelqEver, NumTotalTrades,
#             NumTradesOpeninLast12M, PercentInstallTrades, MSinceMostRecentInqexcl7days, NumInqLast6M,
#             NumInqLast6Mexcl7days, NetFractionRevolvingBurden, NetFractionInstallBurden,
#             NumRevolvingTradesWBalance, NumInstallTradesWBalance, NumBank2NatlTradesWHighUtilization,
#             PercentTradesWBalance
#         ]

#         # Convert input data to numpy array and reshape for prediction
#         input_data = np.array(input_data).reshape(1, -1)

#         # Scale the data before feeding into the model
#         scaled_data = scaler.transform(input_data)

#         # Make prediction using the model
#         prediction = model.predict(scaled_data)

#         return jsonify({'prediction': prediction[0]}), 200

#     except Exception as e:
#         print(f"Error occurred: {str(e)}")
#         return jsonify({'error': str(e)}), 500


# if __name__ == '__main__':
#     app.run(debug=True)
from flask import Flask, render_template, request, jsonify, abort
import joblib
import numpy as np
from tensorflow.keras.models import load_model
import logging

# Initialize Flask app
app = Flask(__name__)

# Configure logging
logging.basicConfig(level=logging.INFO)

# Load the model and scaler
try:
    model = load_model('model.h5')
    scaler = joblib.load('scaler.pkl')
    logging.info("Model and scaler loaded successfully.")
except Exception as e:
    logging.error(f"Error loading model or scaler: {str(e)}")
    raise

# Define the home route
@app.route('/')
def home():
    return render_template('index.html')

# @app.route('/predict', methods=['POST'])
# def predict():
#     try:
#         # Gather input values with validation
#         age = request.form.get('age', type=int)
#         print("Age", age)
#         annual_income = request.form.get('annual_income', type=float)
#         print("annual_income", annual_income)
#         estimated_value_assets = request.form.get('estimated_value_assets', type=float)
#         months_open_credit_account = request.form.get('months_open_credit_account', type=int)
#         number_of_credit_accounts = request.form.get('number_of_credit_accounts', type=int)

#         # Validate required inputs
#         if age is None or annual_income is None or estimated_value_assets is None or months_open_credit_account is None or number_of_credit_accounts is None:
#             return jsonify({'error': 'Missing input data. Age, annual income, estimated value of assets, months open credit account, and number of credit accounts are required.'}), 400

#         employed = request.form.get('employed') == 'yes'
#         overdue_60_days = request.form.get('overdue_60_days') == 'yes'

#         # Additional fields
#         MSinceOldestTradeOpen = request.form.get('MSinceOldestTradeOpen', type=float)
#         MSinceMostRecentTradeOpen = request.form.get('MSinceMostRecentTradeOpen', type=float)
#         AverageMInFile = request.form.get('AverageMInFile', type=float)
#         NumSatisfactoryTrades = request.form.get('NumSatisfactoryTrades', type=float)
#         NumTrades60Ever2DerogPubRec = request.form.get('NumTrades60Ever2DerogPubRec', type=float)
#         NumTrades90Ever2DerogPubRec = request.form.get('NumTrades90Ever2DerogPubRec', type=float)
#         PercentTradesNeverDelq = request.form.get('PercentTradesNeverDelq', type=float)
#         MSinceMostRecentDelq = request.form.get('MSinceMostRecentDelq', type=float)
#         MaxDelq2PublicRecLast12M = request.form.get('MaxDelq2PublicRecLast12M', type=float)
#         MaxDelqEver = request.form.get('MaxDelqEver', type=float)
#         NumTotalTrades = request.form.get('NumTotalTrades', type=float)
#         NumTradesOpeninLast12M = request.form.get('NumTradesOpeninLast12M', type=float)
#         PercentInstallTrades = request.form.get('PercentInstallTrades', type=float)
#         MSinceMostRecentInqexcl7days = request.form.get('MSinceMostRecentInqexcl7days', type=float)
#         NumInqLast6M = request.form.get('NumInqLast6M', type=float)
#         NumInqLast6Mexcl7days = request.form.get('NumInqLast6Mexcl7days', type=float)
#         NetFractionRevolvingBurden = request.form.get('NetFractionRevolvingBurden', type=float)
#         NetFractionInstallBurden = request.form.get('NetFractionInstallBurden', type=float)
#         NumRevolvingTradesWBalance = request.form.get('NumRevolvingTradesWBalance', type=float)
#         NumInstallTradesWBalance = request.form.get('NumInstallTradesWBalance', type=float)
#         NumBank2NatlTradesWHighUtilization = request.form.get('NumBank2NatlTradesWHighUtilization', type=float)
#         PercentTradesWBalance = request.form.get('PercentTradesWBalance', type=float)

#         # Log the received input data
#         app.logger.info("Received input data:")
#         app.logger.info(f"Age: {age}, Employed: {employed}, Annual Income: {annual_income}, Estimated Value of Assets: {estimated_value_assets}")
#         app.logger.info(f"Months Open Credit Account: {months_open_credit_account}, Number of Credit Accounts: {number_of_credit_accounts}, Overdue 60 Days: {overdue_60_days}")

#         # Prepare input data for prediction
#         input_data = [
#             MSinceOldestTradeOpen, MSinceMostRecentTradeOpen, AverageMInFile, NumSatisfactoryTrades,
#             NumTrades60Ever2DerogPubRec, NumTrades90Ever2DerogPubRec, PercentTradesNeverDelq,
#             MSinceMostRecentDelq, MaxDelq2PublicRecLast12M, MaxDelqEver, NumTotalTrades,
#             NumTradesOpeninLast12M, PercentInstallTrades, MSinceMostRecentInqexcl7days, NumInqLast6M,
#             NumInqLast6Mexcl7days, NetFractionRevolvingBurden, NetFractionInstallBurden,
#             NumRevolvingTradesWBalance, NumInstallTradesWBalance, NumBank2NatlTradesWHighUtilization,
#             PercentTradesWBalance
#         ]
        
#         print("Input_Data", input_data)

#         # Convert input data to numpy array and reshape for prediction
#         input_data = np.array(input_data).reshape(1, -1)

#         # Scale the data before feeding into the model
#         scaled_data = scaler.transform(input_data)

#         # Make prediction using the model
#         prediction = model.predict(scaled_data)

#         return jsonify({'prediction': prediction[0].tolist()}), 200

#     except ValueError as ve:
#         app.logger.error(f"Value error: {str(ve)}")
#         return jsonify({'error': 'Invalid input data.'}), 400
#     except Exception as e:
#         app.logger.error(f"Error occurred: {str(e)}")
#         return jsonify({'error': 'An unexpected error occurred.'}), 500

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Gather input values and strip leading zeros where necessary
        age = int(request.form.get('age', '0').lstrip('0') or 0)
        employed = request.form.get('employed') == 'yes'
        annual_income = float(request.form.get('annual_income', '0').lstrip('0') or 0.0)
        estimated_value_assets = float(request.form.get('estimated_value_assets', '0').lstrip('0') or 0.0)
        months_open_credit_account = int(request.form.get('months_open_credit_account', '0').lstrip('0') or 0)
        number_of_credit_accounts = int(request.form.get('number_of_credit_accounts', '0').lstrip('0') or 0)
        overdue_60_days = request.form.get('overdue_60_days') == 'yes'

        # Additional fields, ensuring they are properly parsed
        MSinceOldestTradeOpen = float(request.form.get('MSinceOldestTradeOpen', '0').lstrip('0') or 0.0)
        MSinceMostRecentTradeOpen = float(request.form.get('MSinceMostRecentTradeOpen', '0').lstrip('0') or 0.0)
        AverageMInFile = float(request.form.get('AverageMInFile', '0').lstrip('0') or 0.0)
        NumSatisfactoryTrades = float(request.form.get('NumSatisfactoryTrades', '0').lstrip('0') or 0.0)
        # Handle all other numeric fields similarly...

        # Validate the input data
        if any(field == 0 for field in [age, annual_income, estimated_value_assets, months_open_credit_account, number_of_credit_accounts]):
            return jsonify({'error': 'Missing or incorrect input data.'}), 400

        # Continue with the rest of the function to process the prediction...
        # Ensure proper logging of input data to diagnose issues
        app.logger.info(f"Processed input data: age={age}, employed={employed}, annual_income={annual_income}, estimated_value_assets={estimated_value_assets}")

        # Prepare the input data for prediction
        input_data = [
            MSinceOldestTradeOpen, MSinceMostRecentTradeOpen, AverageMInFile, NumSatisfactoryTrades,
            # Include all other input data fields...
        ]
        input_data = np.array(input_data).reshape(1, -1)

        # Scale and predict
        scaled_data = scaler.transform(input_data)
        prediction = model.predict(scaled_data)

        return jsonify({'prediction': prediction[0]}), 200

    except Exception as e:
        app.logger.error(f"Error during prediction: {str(e)}")
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    app.run(debug=True)
