from flask import Flask, render_template, request, jsonify, abort
import joblib
import numpy as np
from tensorflow.keras.models import load_model
import logging

# Initialize Flask app
app = Flask(__name__)

# Configure logging
logging.basicConfig(level=logging.INFO)

# Load the model and scaler
try:
    model = load_model('model.h5')
    scaler = joblib.load('scaler.pkl')
    logging.info("Model and scaler loaded successfully.")
except Exception as e:
    logging.error(f"Error loading model or scaler: {str(e)}")
    raise

# Define the home route
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Gather and validate the 'age' input
        age = request.form.get('age', type=int)
        if age is None:
            return jsonify({'error': 'Age is required.'}), 400

        app.logger.info(f"Received age: {age}")

        # Prepare the 'age' input data for prediction
        input_data = np.array([[age]])  # Adjusted to match expected input shape

        # Scale the data before feeding into the model
        scaled_data = scaler.transform(input_data)

        # Make prediction using the model
        prediction = model.predict(scaled_data)
        
        # Return the prediction result
        return jsonify({'prediction': round(prediction[0][0], 2)}), 200  # Round for better readability

    except ValueError as ve:
        app.logger.error(f"Value error: {str(ve)}")
        return jsonify({'error': 'Invalid input data. Please check your inputs.'}), 400
    except Exception as e:
        app.logger.error(f"Error occurred: {str(e)}")
        return jsonify({'error': 'An unexpected error occurred. Please try again later.'}), 500

if __name__ == '__main__':
    app.run(debug=True)
