document.addEventListener('DOMContentLoaded', function () {
    const formContainer = document.getElementById('form-container');
    const submitButton = document.getElementById('submitButton');
    const messageContainer = document.getElementById('message-container');

    function handleNextQuestion() {
        const userAnswer = document.getElementById('userInput')?.value || document.querySelector('input[name="options"]:checked')?.value;

        if (userAnswer) {
            fetch('/next-question', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ answer: userAnswer })
            })
            .then(response => response.json())
            .then(data => {
                if (data.question) {
                    renderQuestion(data);
                } else if (data.message) {
                    messageContainer.innerHTML = `<h3>${data.message}</h3>`;
                    formContainer.innerHTML = '';  // Clear form after final message
                    submitButton.style.display = 'none';  // Hide submit button
                }
            });
        }
    }

    function renderQuestion(data) {
        formContainer.innerHTML = ''; // Clear previous question

        const label = document.createElement('label');
        label.textContent = data.question;

        formContainer.appendChild(label);

        if (data.type === 'text' || data.type === 'number') {
            const input = document.createElement('input');
            input.type = data.type;
            input.id = 'userInput';
            input.classList.add('form-control');
            formContainer.appendChild(input);
        } else if (data.type === 'radio') {
            data.options.forEach(option => {
                const radioContainer = document.createElement('div');
                radioContainer.classList.add('form-check');

                const radioInput = document.createElement('input');
                radioInput.type = 'radio';
                radioInput.id = option;
                radioInput.name = 'options';
                radioInput.value = option;
                radioInput.classList.add('form-check-input');

                const radioLabel = document.createElement('label');
                radioLabel.classList.add('form-check-label');
                radioLabel.textContent = option;
                radioLabel.htmlFor = option;

                radioContainer.appendChild(radioInput);
                radioContainer.appendChild(radioLabel);
                formContainer.appendChild(radioContainer);
            });
        } else if (data.type === 'select') {
            const select = document.createElement('select');
            select.id = 'userInput';
            select.classList.add('form-control');
            
            data.options.forEach(option => {
                const optionElement = document.createElement('option');
                optionElement.value = option;
                optionElement.textContent = option;
                select.appendChild(optionElement);
            });
            
            formContainer.appendChild(select);
        }
    }

    submitButton.addEventListener('click', handleNextQuestion);

    // Fetch the first question when the page loads
    fetch('/next-question', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ answer: "" }) })
        .then(response => response.json())
        .then(data => renderQuestion(data));
});
