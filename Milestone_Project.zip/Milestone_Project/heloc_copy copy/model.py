import pandas as pd
import tensorflow as tf
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, BatchNormalization
from tensorflow.keras.callbacks import EarlyStopping
import joblib
import matplotlib.pyplot as plt

# Load the data
file_path = 'heloc_data.csv'
df = pd.read_csv(file_path)

# Convert RiskPerformance to binary (1 for Bad, 0 for Good)
df['RiskPerformanceBinary'] = df['RiskPerformance'].apply(lambda x: 1 if x == 'Bad' else 0)

# Drop the original target column
X = df.drop(['RiskPerformance', 'RiskPerformanceBinary'], axis=1)
y = df['RiskPerformanceBinary']

# Ensure all columns are numeric
X = X.apply(pd.to_numeric, errors='coerce')

# Fill NaN values with median
X.fillna(X.median(), inplace=True)

# Split the data into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Standardize the data (very important for neural networks)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Build the neural network model
model = Sequential()

# Input Layer + First Hidden Layer with 128 neurons and BatchNormalization
model.add(Dense(128, input_dim=X_train_scaled.shape[1], activation='relu'))
model.add(BatchNormalization())  # Normalize after activation
model.add(Dropout(0.3))  # Dropout to prevent overfitting

# Second Hidden Layer with 64 neurons
model.add(Dense(64, activation='relu'))
model.add(BatchNormalization())
model.add(Dropout(0.3))

# Third Hidden Layer with 32 neurons
model.add(Dense(32, activation='relu'))
model.add(BatchNormalization())
model.add(Dropout(0.3))

# Output Layer (Binary Classification)
model.add(Dense(1, activation='sigmoid'))

# Compile the model
model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
              loss='binary_crossentropy',  # Binary classification loss function
              metrics=['accuracy'])

# Early stopping to prevent overfitting
early_stopping = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)

# Train the model with early stopping and validation split
history = model.fit(X_train_scaled, y_train,
                    epochs=100,  # Max number of epochs
                    batch_size=32,  # Number of samples per gradient update
                    validation_split=0.2,  # 20% of training data is used for validation
                    callbacks=[early_stopping],
                    verbose=2)  # Shows progress

# Save the model and scaler
model.save('model.h5')  # Save the trained model to an .h5 file
joblib.dump(scaler, 'scaler.pkl')  # Save the scaler to a .pkl file

# Evaluate the model on the test set
y_pred = (model.predict(X_test_scaled) > 0.5).astype("int32")

# Calculate accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f"Neural Network Accuracy: {accuracy * 100:.2f}%")

# Classification Report
print("\nClassification Report:\n", classification_report(y_test, y_pred))

# Plot the training history (loss and accuracy)
# Plot loss
plt.plot(history.history['loss'], label='train_loss')
plt.plot(history.history['val_loss'], label='val_loss')
plt.title('Model Loss')
plt.ylabel('Loss')
plt.xlabel('Epoch')
plt.legend(loc='upper right')
plt.show()

# Plot accuracy
plt.plot(history.history['accuracy'], label='train_accuracy')
plt.plot(history.history['val_accuracy'], label='val_accuracy')
plt.title('Model Accuracy')
plt.ylabel('Accuracy')
plt.xlabel('Epoch')
plt.legend(loc='upper right')
plt.show()

# Later, to load the model and scaler:
# Load the model
from tensorflow.keras.models import load_model
loaded_model = load_model('model.h5')

# Load the scaler
loaded_scaler = joblib.load('scaler.pkl')

# Now you can use the loaded model and scaler for predictions:
# Example:
# scaled_data = loaded_scaler.transform(new_data)
# prediction = loaded_model.predict(scaled_data)
