import pandas as pd
import xgboost as xgb
import os

# Define file paths
DATA_PATH = 'heloc_data.csv'
MODEL_PATH = 'xgb_heloc_model.json'

# Check if the data file exists
if not os.path.isfile(DATA_PATH):
    raise FileNotFoundError(f"Data file not found: {DATA_PATH}")

# Load the dataset
try:
    data = pd.read_csv(DATA_PATH)
    print("Data loaded successfully.")
    
    # Debugging: Print column names and first few rows
    print("Columns in the dataset:", data.columns.tolist())
    print("First few rows of the dataset:")
    print(data.head())

except Exception as e:
    raise RuntimeError(f"Error loading data: {e}")

# Define target column
target_column = 'RiskPerformance'

# Check if the target column exists
if target_column not in data.columns:
    raise KeyError(f"Column '{target_column}' not found in the dataset.")

# Prepare the data
X = data.drop(target_column, axis=1)
y = data[target_column]

# Print shapes of X and y for debugging
print(f"Features shape: {X.shape}")
print(f"Target shape: {y.shape}")

# Load the model
if not os.path.isfile(MODEL_PATH):
    raise FileNotFoundError(f"Model file not found: {MODEL_PATH}")

try:
    model = xgb.XGBClassifier()
    model.load_model(MODEL_PATH)
    print("Model loaded successfully.")
except Exception as e:
    raise RuntimeError(f"Error loading model: {e}")

# Make predictions (replace this with your actual prediction code)
try:
    predictions = model.predict(X)
    print("Predictions made successfully.")
except Exception as e:
    raise RuntimeError(f"Error making predictions: {e}")

print("Prediction results:")
print(predictions[:5])  # Print the first 5 predictions for inspection
