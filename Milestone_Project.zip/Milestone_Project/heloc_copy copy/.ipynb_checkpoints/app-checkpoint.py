from flask import Flask, render_template, request
import numpy as np
import tensorflow as tf
import joblib

app = Flask(__name__)

# Load the trained model and scaler
try:
    model = tf.keras.models.load_model('trained_model.keras')  # Adjust if needed
except Exception as e:
    print("Error loading model:", e)

try:
    scaler = joblib.load('scaler.pkl')  # Adjust the filename if needed
except Exception as e:
    print("Error loading scaler:", e)

# Global state to hold user data during the session
user_state = {
    "age": None,
    "employment": None,
    "income": None,
    "assets": None,
    "risk": None,
    "credit_accounts": None,
    "credit_history_length": None,
    "late_payments": None,
    "bankruptcy": None
}

# Questions list
questions = [
    {"text": "What is your age?", "type": "number"},
    {"text": "Are you currently working", "type": "radio", "options": ["yes", "no"]},
    {"text": "What is your annual income?", "type": "number"},
    {"text": "What is your estimated amount of assets?", "type": "number"},
    {"text": "How many credit accounts have you opened in the last 12 months?", "type": "number"},
    {"text": "How long ago did you open your first credit account?", "type": "radio", "options": ["Less than 5 years", "5-10 years", "More than 10 years"]},
    {"text": "Have you had any late credit payments (60 days or more) or bankruptcy/public derogatory records?", "type": "radio", "options": ["yes", "no"]}
]

# Question index to track current question
question_index = 0

@app.route('/')
def index():
    global question_index
    question_index = 0  # Reset question index when the user starts fresh
    return render_template('index.html', question=questions[question_index], error=None)

@app.route('/next-question', methods=['POST'])
def next_question():
    global question_index
    user_response = request.form.get('userInput')

    # Validate and process user input for each question
    if question_index == 0:
        if user_response and user_response.isdigit():
            user_state["age"] = int(user_response)
        else:
            return render_template('index.html', question=questions[question_index], error="Please enter a valid age.")
    
    elif question_index == 1:
        if user_response in ["yes", "no"]:
            user_state["employment"] = user_response
        else:
            return render_template('index.html', question=questions[question_index], error="Please select a valid option.")
    
    elif question_index == 2:
        if user_state["employment"] == "yes":
            if user_response and user_response.isdigit():
                user_state["income"] = int(user_response)
            else:
                return render_template('index.html', question=questions[question_index], error="Please enter a valid income.")
        else:
            user_state["income"] = 0  # Unemployed users have no income
    
    elif question_index == 3:
        if user_response and user_response.isdigit():
            user_state["assets"] = int(user_response)
        else:
            return render_template('index.html', question=questions[question_index], error="Please enter a valid asset value.")
    
    elif question_index == 4:
        if user_response.isdigit():
            user_state["credit_accounts"] = int(user_response)
        else:
            return render_template('index.html', question=questions[question_index], error="Please enter a valid number of credit accounts.")
    
    elif question_index == 5:
        if user_response in ["Less than 5 years", "5-10 years", "More than 10 years"]:
            user_state["credit_history_length"] = user_response
        else:
            return render_template('index.html', question=questions[question_index], error="Please select a valid credit history length.")
    
    elif question_index == 6:
        if user_response in ["yes", "no"]:
            user_state["late_payments"] = user_response
            user_state["bankruptcy"] = user_response
        else:
            return render_template('index.html', question=questions[question_index], error="Please select a valid option.")

    # Move to next question or make predictions if it's the last question
    question_index += 1

    if question_index < len(questions):
        return render_template('index.html', question=questions[question_index], error=None)
    else:
        # All questions answered, make a prediction
        return predict_risk()

def predict_risk():
    # Collect user inputs and transform into a form suitable for the model
    user_input = np.array([
        user_state["age"],
        user_state["income"],
        user_state["assets"],
        user_state["credit_accounts"],
        1 if user_state["credit_history_length"] == "More than 10 years" else (0 if user_state["credit_history_length"] == "Less than 5 years" else 0.5),
        1 if user_state["late_payments"] == "yes" else 0,
        1 if user_state["bankruptcy"] == "yes" else 0
    ]).reshape(1, -1)
    
    user_input_scaled = scaler.transform(user_input)
    prediction = model.predict(user_input_scaled)[0][0]
    
    # Interpret the prediction
    risk = "High Risk" if prediction >= 0.5 else "Low Risk"
    
    return render_template('result.html', risk=risk)

if __name__ == '__main__':
    app.run(debug=True)
