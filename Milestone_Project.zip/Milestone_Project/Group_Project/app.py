from flask import Flask, request, render_template
import numpy as np
import joblib
import csv
import os
import pandas as pd
from explanatory_shap import predict_fico_scores
import matplotlib
matplotlib.use('Agg')  # Use 'Agg' backend for non-GUI environments
import matplotlib.pyplot as plt
from flask import send_file  # Add this import at the top with other imports

app = Flask(__name__)

# Load the pre-trained Random Forest model
model = joblib.load('best_rf_model.pkl')  # Random Forest model

@app.route('/')
def external_risk():
    return render_template('external_risk.html')

@app.route('/index')
def index():
    # Pass external risk value to the index template if it exists
    external_risk = request.args.get('externalRisk', None)
    return render_template('index.html', external_risk=external_risk)

@app.route('/predict', methods=['POST'])
def predict():
    shap_images = []  # Initialize shap_images to avoid UnboundLocalError
    temp_input_csv = 'temp_input.csv'
    try:
        external_risk_estimate = request.form.get('ExternalRiskEstimate')
        form_data = request.form.to_dict()
        print("FORM", form_data)

        # Define CSV file path
        csv_file = 'input_data.csv'
        file_exists = os.path.isfile(csv_file)

        # Append data to the CSV file
        with open(csv_file, mode='a', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=form_data.keys())
            if not file_exists:
                writer.writeheader()  # Write the header only once
            writer.writerow(form_data)

        # Create input array
        input_data = []
        for feature in form_data.keys():
            value = form_data.get(feature)
            if not value:  # Check if a value was provided for each feature
                return f"Missing input for {feature}, please provide all required values."
            input_data.append(float(value))

        # Convert input data to numpy array
        input_data = np.array(input_data).reshape(1, -1)
        print("Input Data", input_data)

        # Predict using the Random Forest model (no scaling)
        prediction = model.predict(input_data)
        print("prediction", prediction)
        predicted_class = 'Good' if prediction[0] == 1 else 'Bad'

        # Generate SHAP plots
        # pd.DataFrame(int(input_data)).to_csv(temp_input_csv, index=False)
        df = pd.DataFrame(input_data.astype(int))

        # Define the file name and the same directory as the script
        temp_input_csv = os.path.join(os.path.dirname(__file__), 'input_data.csv')

        shap_images = predict_fico_scores(temp_input_csv)  # Get SHAP image paths
        print("Shap Imagd", shap_images)

    except Exception as e:
        print(f"Error occurred: {e}")
        # Optionally log the error or return an error message
    # finally:
    #     if os.path.exists(temp_input_csv):
    #         os.remove(temp_input_csv)  # Cleanup temporary CSV

        # Return prediction result along with SHAP images
    return render_template('results.html', prediction=predicted_class)

    
# @app.route('/download_plot')
# def download_plot():
#     return send_file('shap_plot.png', mimetype='image/png', as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
