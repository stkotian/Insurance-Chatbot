import numpy as np
import pandas as pd
import joblib
import shap
import matplotlib.pyplot as plt
 
 
def predict_fico_scores(input_csv, model_file='best_rf_model.pkl'):
    # Load the trained model
    rf_model = joblib.load(model_file)
   
    # Load the new input CSV file
    input_data = pd.read_csv(input_csv)
   
    # Predict FICO score for each participant
    predictions = rf_model.predict(input_data)
   
    # Add predictions as a new column in the input data
    input_data['FICO_Prediction'] = predictions
   
    # Save the predictions to a new CSV file
    output_file = 'fico_predictions.csv'
    input_data.to_csv(output_file, index=False)
    print(f"Predictions saved to {output_file}")
   
    # Drop the prediction column before SHAP analysis
    input_data_cleaned = input_data.drop(columns=['FICO_Prediction'])
   
    # Now let's compute SHAP values for feature importance
    explainer_rf, shap_values_rf = compute_shap_values(rf_model, input_data_cleaned)
   
    # Visualize SHAP values for each prediction based on the predicted class
    for i in range(input_data_cleaned.shape[0]):
        print(i)
        visualize_shap_values(explainer_rf, shap_values_rf, input_data_cleaned, predictions[i], index=i)
   
# SHAP functions
def compute_shap_values(model, X_data):
    # Create a SHAP explainer for the Random Forest model
    explainer = shap.TreeExplainer(model)
   
    # Compute SHAP values for the given dataset
    shap_values = explainer.shap_values(X_data)
   
    print("SHAP values for all instances and features computed.")
   
    return explainer, shap_values
 
def visualize_shap_values(explainer, shap_values, X_data, prediction, index=None):
    # Initialize a list to store SHAP values for both classes for each feature as a tuple
    class_shap_values = []

    # Loop through each feature and store SHAP values for both classes (0 and 1) as tuples
    for i in range(X_data.shape[1]):
        # Append a tuple (shap_value_class_0, shap_value_class_1) for each feature
        class_shap_values.append((shap_values[index][i][0], shap_values[index][i][1]))

    # Ensure SHAP values match the feature matrix shape
    if len(class_shap_values) != X_data.shape[1]:
        raise ValueError(f"Mismatch in number of features: SHAP values have {len(class_shap_values)}, "
                         f"but feature matrix has {X_data.shape[1]}")

    # Extract SHAP values for the predicted class (0 or 1) from the tuples
    shap_values_for_predicted_class = [shap_tuple[prediction] for shap_tuple in class_shap_values]

    # Feature names
    feature_names = [
        "ExternalRiskEstimate", "MSinceOldestTradeOpen", "MSinceMostRecentTradeOpen",
        "AverageMInFile", "NumSatisfactoryTrades", "NumTrades60Ever2DerogPubRec",
        "NumTrades90Ever2DerogPubRec", "PercentTradesNeverDelq", "MSinceMostRecentDelq",
        "MaxDelq2PublicRecLast12M", "MaxDelqEver", "NumTotalTrades",
        "NumTradesOpeninLast12M", "PercentInstallTrades", "MSinceMostRecentInqexcl7days",
        "NumInqLast6M", "NumInqLast6Mexcl7days", "NetFractionRevolvingBurden",
        "NetFractionInstallBurden", "NumRevolvingTradesWBalance", "NumInstallTradesWBalance",
        "NumBank2NatlTradesWHighUtilization", "PercentTradesWBalance"
    ]

    # Convert SHAP values to numpy array
    shap_values_array = np.array(shap_values_for_predicted_class)

    # Sort SHAP values
    sorted_indices = np.argsort(shap_values_array)[::-1]

    # Extract the sorted SHAP values and feature names
    sorted_shap_values = shap_values_array[sorted_indices]
    sorted_feature_names = [feature_names[i] for i in sorted_indices]

    # Plot SHAP values
    plt.figure(figsize=(10, 8))
    bars = plt.barh(sorted_feature_names, sorted_shap_values, color='b')

    # Set color based on predicted class
    positive_color, negative_color = ('#28B463', '#FF5733') if prediction else ('#FF5733', '#28B463')

    for i, bar in enumerate(bars):
        bar.set_color(positive_color if sorted_shap_values[i] > 0 else negative_color)

    predicted_class = "Good FICO" if prediction == 1 else "Bad FICO"

    plt.legend(handles=[plt.Rectangle((0, 0), 1, 1, color=positive_color, label='Contribution towards predicted class'),
                        plt.Rectangle((0, 0), 1, 1, color=negative_color, label='Contribution against predicted class')],
               loc='lower right')

    plt.xlabel('SHAP Value')
    plt.title(f'SHAP Values for All Features\nPredicted Class: {predicted_class}')
    plt.gca().invert_yaxis()  # Invert y-axis
    plt.savefig('static/shap_plot.png')  # Save the plot to a file
    plt.close()  # Close the plot to free memory

 
# Example usage of prediction function
#predict_fico_scores('temp_input.csv')