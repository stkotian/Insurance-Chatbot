import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import accuracy_score, classification_report
import joblib

# Load the dataset (replace with actual dataset path)
heloc_df = pd.read_csv('heloc_dataset_v1.csv')

# Define features and target variable
X = heloc_df.drop(columns=['RiskPerformance'])  # Drop the target column 'RiskPerformance'
y = heloc_df['RiskPerformance'].apply(lambda x: 1 if x == 'Good' else 0)  # Convert target to binary

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Define the parameter grid for Random Forest
param_grid_rf = {
    'n_estimators': [100, 300, 500],
    'max_depth': [10, 20, None],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'bootstrap': [True, False]
}

# Initialize Random Forest Classifier
rf = RandomForestClassifier(random_state=42)

# Set up GridSearchCV
grid_search_rf = GridSearchCV(estimator=rf, param_grid=param_grid_rf, cv=5, n_jobs=-1, verbose=2)

# Train the model
grid_search_rf.fit(X_train, y_train)

# Get the best model
best_rf = grid_search_rf.best_estimator_

# Save the trained model
joblib.dump(best_rf, 'best_rf_model.pkl')
print("Model saved successfully!")

# Evaluate the model on the test set
y_pred_rf = best_rf.predict(X_test)
accuracy = accuracy_score(y_test, y_pred_rf)
print(f"Accuracy of the best Random Forest model: {accuracy}")
print("Classification Report for the Best Random Forest Model")
print(classification_report(y_test, y_pred_rf))