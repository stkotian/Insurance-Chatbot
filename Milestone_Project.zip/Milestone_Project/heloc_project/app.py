from flask import Flask, render_template, request

app = Flask(__name__)

# Global state to hold user data during the session
user_state = {
    "age": None,
    "employment": None,
    "income": None,
    "assets": None,
    "risk": None,
    "credit_accounts": None,
    "credit_history_length": None,
    "late_payments": None,
    "bankruptcy": None
}

# Questions list
questions = [
    {"text": "What is your age?", "type": "number"},
    {"text": "Are you currently working", "type": "radio", "options": ["yes", "no"]},
    {"text": "What is your annual income?", "type": "number"},
    {"text": "What is your estimated amount of assets?", "type": "number"},
    {"text": "How many credit accounts have you opened in the last 12 months?", "type": "number"},
    {"text": "How long ago did you open your first credit account?", "type": "radio", "options": ["Less than 5 years", "5-10 years", "More than 10 years"]},
    {"text": "Have you had any late credit payments (60 days or more) or bankruptcy/public derogatory records?", "type": "radio", "options": ["yes", "no"]}
]

# Question index to track current question
question_index = 0

# Home route to render the initial page
@app.route('/')
def index():
    global question_index
    question_index = 0  # Reset question index when the user starts fresh
    return render_template('index.html', question=questions[question_index], error=None)

# Route to process the next question
@app.route('/next-question', methods=['POST'])
def next_question():
    global question_index
    user_response = request.form.get('userInput')  # Get user input

    # Validate and process user input for each question
    if question_index == 0:  # Age question
        if user_response and user_response.isdigit():
            user_state["age"] = int(user_response)
        else:
            return render_template('index.html', question=questions[question_index], error="Please enter a valid age.")
    
    elif question_index == 1:  # Employment status question
        if user_response in ["yes", "no"]:
            user_state["employment"] = user_response
        else:
            return render_template('index.html', question=questions[question_index], error="Please select a valid option.")
    
    elif question_index == 2:  # Income question
        if user_state["employment"] == "yes":
            if user_response and user_response.isdigit():
                user_state["income"] = int(user_response)
            else:
                return render_template('index.html', question=questions[question_index], error="Please enter a valid income.")
        else:
            # Skip the income question if the user is unemployed and move to the next question
            user_state["income"] = 0
            question_index += 1  # Skip to assets question
    
    elif question_index == 3:  # Assets question
        if user_response and user_response.isdigit():
            user_state["assets"] = int(user_response)
        else:
            return render_template('index.html', question=questions[question_index], error="Please enter a valid asset amount.")
    
    elif question_index == 4:  # Credit accounts question
        if user_response and user_response.isdigit():
            user_state["credit_accounts"] = int(user_response)
        else:
            return render_template('index.html', question=questions[question_index], error="Please enter a valid number of accounts.")
    
    elif question_index == 5:  # Credit history length
        if user_response in ["Less than 5 years", "5-10 years", "More than 10 years"]:
            user_state["credit_history_length"] = user_response
        else:
            return render_template('index.html', question=questions[question_index], error="Please select a valid option.")
    
    elif question_index == 6:  # Late payments or bankruptcy
        if user_response in ["yes", "no"]:
            user_state["late_payments"] = (user_response == "yes")
        else:
            return render_template('index.html', question=questions[question_index], error="Please select a valid option.")

        # After all questions, determine risk
        user_state["risk"] = determine_risk()
        return render_template('thank_you.html', risk=user_state["risk"])

    # Increment question index to move to the next question
    question_index += 1
    return render_template('index.html', question=questions[question_index], error=None)

# Function to determine the risk based on the user's inputs
def determine_risk():
    age = user_state["age"]
    income = user_state["income"]
    assets = user_state["assets"]
    credit_accounts = user_state["credit_accounts"]
    credit_history_length = user_state["credit_history_length"]
    late_payments = user_state["late_payments"]

    # Determine initial risk level based on age, income, and assets
    if age > 55 and income > 100000 and assets > 1000000:
        risk = "Low Risk"
    elif age <= 55 and (income < 40000 or assets < 100000):
        risk = "High Risk"
    else:
        risk = "Medium Risk"

    # Adjust risk based on credit account and credit history
    if credit_accounts == 1 or credit_accounts == 2:
        risk = "Moderately Stable"
    elif credit_accounts > 2:
        risk = "Less Stable"

    # Adjust risk based on credit history length
    if credit_history_length == "Less than 5 years":
        risk = "Less Stable"
    elif credit_history_length == "5-10 years":
        risk = "Moderately Stable"
    elif credit_history_length == "More than 10 years":
        risk = "More Stable"

    # Adjust further for late payments or bankruptcy
    if late_payments:
        risk = "High Risk"

    return risk

# Run the Flask app
if __name__ == '__main__':
    app.run(debug=True)
