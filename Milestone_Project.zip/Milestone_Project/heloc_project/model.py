# import pandas as pd
# import xgboost as xgb
# from sklearn.model_selection import train_test_split
# from sklearn.metrics import accuracy_score

# # Load HELOC dataset
# data = pd.read_csv('heloc_data.csv')

# # Replace missing values (if any) with mean
# data.fillna(data.mean(), inplace=True)

# # Split data into features and labels
# X = data.drop('RiskPerformance', axis=1)
# y = data['RiskPerformance'].apply(lambda x: 1 if x == 'Bad' else 0)  # Binary classification: Bad=1, Good=0

# # Train-test split
# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# # Initialize and train XGBoost model
# model = xgb.XGBClassifier()
# model.fit(X_train, y_train)

# # Save the model
# model.save_model('xgb_heloc_model.json')

# # Optionally, evaluate the model on the test set
# y_pred = model.predict(X_test)
# accuracy = accuracy_score(y_test, y_pred)
# print(f'Model accuracy: {accuracy}')




# import xgboost as xgb
# import pandas as pd
# from sklearn.model_selection import train_test_split
# import os

# # Define file paths
# DATA_PATH = 'heloc_data.csv'
# MODEL_PATH = 'xgb_heloc_model.json'
# MODEL_DIR = os.path.dirname(MODEL_PATH)

# # Ensure the model directory exists
# if not os.path.exists(MODEL_DIR) and MODEL_DIR:
#     os.makedirs(MODEL_DIR)

# # Check if the data file exists
# if not os.path.isfile(DATA_PATH):
#     raise FileNotFoundError(f"Data file not found: {DATA_PATH}")

# # Load dataset
# data = pd.read_csv(DATA_PATH)
# X = data.drop('target', axis=1)  # Replace 'target' with your actual target column name
# y = data['target']

# # Split the dataset
# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# # Initialize and train the model
# model = xgb.XGBClassifier(use_label_encoder=False)

# try:
#     model.fit(X_train, y_train)
#     print("Model trained successfully.")
# except Exception as e:
#     print(f"Error training model: {e}")

# # Save the model
# try:
#     model.save_model(MODEL_PATH)
#     print("Model saved successfully.")
# except Exception as e:
#     print(f"Error saving model: {e}")



import xgboost as xgb
import pandas as pd
import os
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Load the HELOC data
data_path = 'heloc_data.csv'
print(f"Loading data from: {data_path}")
data = pd.read_csv(data_path)
print(f"Data loaded successfully. Shape: {data.shape}")

# Data Preprocessing (adjust this part as needed based on your requirements)
print("Preprocessing data...")
X = data.drop('RiskPerformance', axis=1)
y = data['RiskPerformance'].map({'Good': 1, 'Bad': 0})

# Split the data
print("Splitting data into training and testing sets...")

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
print(f"Training set shape: {X_train.shape}")
print(f"Testing set shape: {X_test.shape}")

# Initialize and train the XGBoost model
print("Initializing the XGBoost model...")
model = xgb.XGBClassifier(use_label_encoder=False, eval_metric='logloss')

print("Training the model...")

try:
    model.fit(X_train, y_train)
    print("Model trained successfully.")
except Exception as e:
    print(f"Error during training: {e}")

# Evaluate the model
print("Evaluating the model...")
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f"Model accuracy: {accuracy:.4f}")

# Save the model
try:
    # Attempt to save in the current directory
    print("Saving model to xgb_heloc_model.json...")
    model.save_model('xgb_heloc_model.json')
    print("Model saved successfully to the current directory.")
except Exception as e:
    print(f"Error saving model in current directory: {e}")
    
    
# Verify the saved model file
print(f"Checking if model file exists...")
if os.path.exists('xgb_heloc_model.json'):
    print("Model file exists in the current directory.")
else:
    print("Model file does not exist in the current directory.")
    
    
# Check file system permissions
try:
    print("Creating a test file to check permissions...")
    test_file = 'test_file.txt'
    with open(test_file, 'w') as f:
        f.write("Hello, this is a test file to check permissions.")
    print(f"Test file {test_file} created successfully.")
    os.remove(test_file)
    print("Test file removed successfully.")
except Exception as e:
    print(f"Error creating test file: {e}")
    
    
# Print current working directory
print(f"Current working directory: {os.getcwd()}")

    