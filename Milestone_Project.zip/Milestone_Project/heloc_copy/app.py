# # app.py

# import numpy as np
# import pandas as pd
# import tensorflow as tf
# from flask import Flask, request, render_template
# from sklearn.preprocessing import StandardScaler

# # Load the model
# model = tf.keras.models.load_model('heloc_model.h5')

# # Initialize the Flask app
# app = Flask(__name__)

# # Load the scaler
# scaler = StandardScaler()
# # Fit the scaler with example data, you can replace this with your actual feature columns
# example_data = pd.read_csv('heloc_data.csv')
# X_example = example_data.drop(['RiskPerformance', 'RiskPerformanceBinary'], axis=1)
# X_example = X_example.apply(pd.to_numeric, errors='coerce').fillna(X_example.median())
# scaler.fit(X_example)

# # Define the home route
# @app.route('/')
# def home():
#     return render_template('index.html')

# # Define the prediction route
# @app.route('/predict', methods=['POST'])
# def predict():
#     # Get feature values from form
#     features = [float(request.form[str(i)]) for i in range(len(X_example.columns))]
#     features_scaled = scaler.transform([features])
    
#     # Make prediction
#     prediction = model.predict(features_scaled)
#     risk = 'Bad' if prediction[0][0] > 0.5 else 'Good'
    
#     return render_template('result.html', risk=risk)

# # Run the app
# if __name__ == '__main__':
#     app.run(debug=True)


# import pandas as pd
# import tensorflow as tf
# from flask import Flask, request, jsonify

# app = Flask(__name__)

# # Load the model
# model = tf.keras.models.load_model('heloc_model.h5')

# # Load and preprocess the dataset to create the binary target
# df = pd.read_csv('heloc_data.csv')
# df['RiskPerformanceBinary'] = df['RiskPerformance'].apply(lambda x: 1 if x == 'Bad' else 0)

# @app.route('/predict', methods=['POST'])
# def predict():
#     # Assume you receive input data in JSON format
#     example_data = pd.DataFrame(request.json)
    
#     # Check columns in the example data
#     print("Example Data Columns:", example_data.columns)

#     # Drop only if the column exists
#     if 'RiskPerformance' in example_data.columns:
#         X_example = example_data.drop(['RiskPerformance'], axis=1)
#     else:
#         return jsonify({"error": "RiskPerformance column not found"}), 400

#     # Ensure all columns are numeric
#     X_example = X_example.apply(pd.to_numeric, errors='coerce')

#     # Fill NaN values with median
#     X_example.fillna(X_example.median(), inplace=True)

#     # Scale the data
#     scaler = StandardScaler()
#     X_example_scaled = scaler.fit_transform(X_example)

#     # Make a prediction
#     prediction = model.predict(X_example_scaled)
#     prediction_class = (prediction > 0.5).astype("int32")

#     return jsonify({"prediction": prediction_class.tolist()})

# if __name__ == '__main__':
#     app.run(debug=True)


from flask import Flask, render_template, request, jsonify
import joblib
import numpy as np
from tensorflow.keras.models import load_model

# Initialize Flask app
app = Flask(__name__)

# Load the model and scaler
model = load_model('model.h5')
scaler = joblib.load('scaler.pkl')

# Define the home route
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Extract form data corresponding to the original 23 features
        input_data = [
            float(request.form.get('ExternalRiskEstimate', 50)),  # Default value if not provided
            float(request.form.get('MSinceOldestTradeOpen', 50)),
            float(request.form.get('MSinceMostRecentTradeOpen', 50)),
            float(request.form.get('AverageMInFile', 24)),
            float(request.form.get('NumSatisfactoryTrades', 10)),
            float(request.form.get('NumTrades60Ever2DerogPubRec', 0)),
            float(request.form.get('NumTrades90Ever2DerogPubRec', 0)),
            float(request.form.get('PercentTradesNeverDelq', 100)),
            float(request.form.get('MSinceMostRecentDelq', 12)),
            float(request.form.get('MaxDelq2PublicRecLast12M', 0)),
            float(request.form.get('MaxDelqEver', 0)),
            float(request.form.get('NumTotalTrades', 5)),
            float(request.form.get('NumTradesOpeninLast12M', 0)),
            float(request.form.get('PercentInstallTrades', 1)),
            float(request.form.get('MSinceMostRecentInqexcl7days', 12)),
            float(request.form.get('NumInqLast6M', 0)),
            float(request.form.get('NumInqLast6Mexcl7days', 0)),
            float(request.form.get('NetFractionRevolvingBurden', 21)),
            float(request.form.get('NetFractionInstallBurden', 12)),
            float(request.form.get('NumRevolvingTradesWBalance', 1)),
            float(request.form.get('NumInstallTradesWBalance', 0)),
            float(request.form.get('NumBank2NatlTradesWHighUtilization', 3)),
            float(request.form.get('PercentTradesWBalance', 3))
        ]

        # Convert input data to numpy array and reshape for prediction
        input_data = np.array(input_data).reshape(1, -1)

        # Scale the data before feeding into the model
        scaled_data = scaler.transform(input_data)

        # Make a prediction
        prediction = model.predict(scaled_data)
        prediction = (prediction > 0.5).astype(int)

        return jsonify({'prediction': 'Bad' if prediction[0][0] == 1 else 'Good'})

    except Exception as e:
        return jsonify({'error': str(e)})



if __name__ == '__main__':
    app.run(debug=True)
